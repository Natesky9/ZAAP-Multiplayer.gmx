# ZAAP-Multiplayer.gmx
ZAAP v.04

ZAAP is a multiplayer space-themed game inspired by the classic, Freelancer
It combines the combat, trading, and adventure of the classic space theme
with the addition of processing, production, and customization of a
sandbox that allows you to build your ship to fit your style and occupation,
while allowing creative uses of parts, weapons, and technology

This is (currently) version .04

# What has been added:
//----------------------------------------------------//
-Dynamic Menu system
-Customizable buttons and buttons that are saved
-command-line interface for help and commands
//----------------------------------------------------//
